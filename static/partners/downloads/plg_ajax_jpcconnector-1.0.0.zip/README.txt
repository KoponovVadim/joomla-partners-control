JPC Connector 1.0.0 for Joomla 3.10
======================================

Назначение
----------
Плагин предоставляет Joomla Partners Control защищённый JSON endpoint
через публичный com_ajax. Он нужен для сайтов, где хостинг блокирует
автоматический доступ к /administrator/.

Установка
---------
1. Joomla: Расширения -> Менеджер расширений -> Установка.
2. Загрузите ZIP plg_ajax_jpcconnector-1.0.0.zip.
3. Скопируйте показанный после установки Connector Token.
4. При необходимости откройте Плагины -> JPC Connector и укажите
   исходящий IP production-сервера JPC.
5. В JPC выберите:
   Версия Joomla: Joomla 3
   Авторизация: JPC Connector (Joomla 3)
   Вставьте Connector Token и сохраните.
6. Нажмите "Проверить подключение".

Endpoint по умолчанию
---------------------
/index.php?option=com_ajax&plugin=jpcconnector&format=raw

Безопасность
------------
- token передаётся только в заголовке X-JPC-Token;
- первый успешный запрос заменяет token в базе Joomla необратимым хешем;
- redirects не используются;
- update требует правильный managed-marker и SHA-256 прочитанной версии;
- размер JSON запроса ограничен 2 МБ;
- разрешённый IP можно ограничить в настройках плагина.
